<?php
$player = array (
    0 => array (
      "name" => "Susan",
      "moves" => 12
    ),
    1 => array (
      "name" => "Catherine",
      "moves" => 13
    ),
    2 => array (
      "name" => "Anne",
      "moves" => 11
    ),
    3 => array (
      "name" => "Bonnie",
      "moves" => 16
    ),
    4 => array (
      "name" => "Rebecca",
      "moves" => 10
    ),
    5 => array (
      "name" => "Margaret",
      "moves" => 17
    ),
    6 => array (
      "name" => "Deborah",
      "moves" => 15
    )
);
?>